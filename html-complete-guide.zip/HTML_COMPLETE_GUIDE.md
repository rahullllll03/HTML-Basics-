# HTML Complete Guide (Beginner to Professional)

## 1. Introduction to HTML
HTML (HyperText Markup Language) is the standard language used to create and structure web pages.

### Key Features
- Platform independent
- Easy to learn
- Supported by all browsers

---

## 2. Basic HTML Structure
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
</head>
<body>
  <h1>Hello World</h1>
</body>
</html>
```

---

## 3. HTML Elements
- Headings: `<h1>` to `<h6>`
- Paragraph: `<p>`
- Links: `<a>`
- Images: `<img>`
- Line Break: `<br>`

---

## 4. Attributes
Attributes provide additional information about elements.

Example:
```html
<a href="https://example.com" target="_blank">Visit</a>
```

---

## 5. Text Formatting
- Bold: `<b>`
- Italic: `<i>`
- Underline: `<u>`
- Strong: `<strong>`
- Emphasis: `<em>`

---

## 6. Lists
### Ordered List
```html
<ol>
  <li>HTML</li>
  <li>CSS</li>
</ol>
```

### Unordered List
```html
<ul>
  <li>JavaScript</li>
</ul>
```

---

## 7. Tables
```html
<table border="1">
  <tr>
    <th>Name</th>
    <th>Role</th>
  </tr>
  <tr>
    <td>Rahul</td>
    <td>Developer</td>
  </tr>
</table>
```

---

## 8. Forms
```html
<form>
  <input type="text" placeholder="Name">
  <input type="email" placeholder="Email">
  <button type="submit">Submit</button>
</form>
```

---

## 9. Multimedia
- Images: `<img>`
- Audio: `<audio>`
- Video: `<video>`

---

## 10. Semantic HTML
Semantic tags improve readability and SEO.

Examples:
- `<header>`
- `<nav>`
- `<section>`
- `<article>`
- `<footer>`

---

## 11. Meta Tags
```html
<meta name="description" content="HTML Guide">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
```

---

## 12. HTML5 Features
- Semantic elements
- Audio & Video support
- Local Storage
- Responsive design support

---

## 13. Best Practices
- Use semantic tags
- Proper indentation
- Meaningful titles
- Accessibility (alt attributes)

---

## 14. SEO & Accessibility
- Use `<alt>` in images
- Proper heading hierarchy
- Meta descriptions

---

## 15. Conclusion
HTML is the foundation of web development. Mastering HTML ensures clean, accessible, and professional web pages.
