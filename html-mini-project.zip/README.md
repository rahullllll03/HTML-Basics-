# HTML Mini Project – Student Portfolio

## 📌 Project Overview
This is a **next-level beginner HTML mini project** created to help students understand how real websites are structured.

The project uses **pure HTML and CSS** and focuses on layout, structure, and semantic tags.

---

## 🛠 Technologies Used
- HTML5
- CSS3

---

## 📂 Project Structure
```
html-mini-project/
├── index.html
├── style.css
└── README.md
```

---

## ✨ Features
- Semantic HTML structure
- Navigation bar
- About & Skills section
- Project table
- Contact form
- Clean and responsive layout

---

## 🎯 Learning Outcomes
- Understanding website layout
- Using semantic tags
- Forms and tables
- Linking CSS with HTML

---

## 🚀 How to Run
Simply open `index.html` in your browser.

---

## 📌 Ideal For
- Beginners
- College mini projects
- HTML practice
- GitHub portfolio

---

Happy Learning 🚀
